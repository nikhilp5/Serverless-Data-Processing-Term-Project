const OpenAI = require('openai');

// Initialize with your OpenAI secret key
const openai = new OpenAI(process.env.OPENAI_SECRET_KEY);

exports.handler = async (event, context) => {
  try {
    const gpt3Response = await openai.Completion.create({
      engine: 'davinci-codex',
      prompt: 'Generate a funny team name',
      temperature: 0.5,
      max_tokens: 5
    });

    // Extract the team name from the response
    const teamName = gpt3Response.choices[0].text.trim();

    return {
      statusCode: 200,
      body: JSON.stringify({ teamName }),
    };
  } catch (error) {
    console.log(error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Failed to generate a team name' }),
    };
  }
};
